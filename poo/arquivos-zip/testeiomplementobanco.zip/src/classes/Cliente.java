package classes;

public class Cliente extends Cadastro {
	private int idcliente;

	public int getIdcliente() {
		return idcliente;
	}

	public void setIdcliente(int idcliente) {
		this.idcliente = idcliente;
	}
	
}
