package classes;

public class Cliente extends Pessoa {
	private int idcliente;
	

	public int getIdcliente() {
		return idcliente;
	}

	public void setIdcliente(int idcliente) {
		this.idcliente = idcliente;
	}
}
