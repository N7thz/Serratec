package com.escola.serratec;

public enum DiasSemana {
	DOMINGO,
	SEGUNDA_FEIRA,
	TERCA_FEIRA,
	QUARTA_FEIRA,
	QUINTA_FEIRA,
	SEXTA_FEIRA,
	SABADO;
}
