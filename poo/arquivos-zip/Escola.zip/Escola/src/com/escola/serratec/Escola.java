package com.escola.serratec;

public class Escola {
	DiasSemana diaSemana;
	
	public void teste() {
		this.diaSemana = DiasSemana.QUARTA_FEIRA;
	}
}
