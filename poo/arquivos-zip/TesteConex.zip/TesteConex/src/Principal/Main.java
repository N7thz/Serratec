package Principal;

import conexao.DadosDeEntrada;

public class Main {
	public static void main(String[] args) {
		DadosDeEntrada.dadosEntrada();
	}
}
