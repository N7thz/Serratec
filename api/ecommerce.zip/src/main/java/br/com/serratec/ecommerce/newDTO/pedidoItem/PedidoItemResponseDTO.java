package br.com.serratec.ecommerce.newDTO.pedidoItem;

public class PedidoItemResponseDTO extends PedidoItemBaseDTO {
    
}
