package br.com.serratec.ecommerce.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class TipoUsuario {
<<<<<<< HEAD

=======
    
>>>>>>> 4f49083b1cbac423c45740a855ad0bc21491e879
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tipoUsuarioId;

    @Column(nullable = false)
    private String tipoUsu;

    public TipoUsuario(Long tipoUsuarioId, String tipoUsu) {
        this.tipoUsuarioId = tipoUsuarioId;
        this.tipoUsu = tipoUsu;
    }

<<<<<<< HEAD
    public TipoUsuario() {}

=======
>>>>>>> 4f49083b1cbac423c45740a855ad0bc21491e879
// #region Getters and Setters

    public Long getTipoUsuarioId() {
        return tipoUsuarioId;
    }

    public void setTipoUsuarioId(Long tipoUsuarioId) {
        this.tipoUsuarioId = tipoUsuarioId;
    }

    public String getTipoUsu() {
        return tipoUsu;
    }

    public void setTipoUsu(String tipoUsu) {
        this.tipoUsu = tipoUsu;
    }
<<<<<<< HEAD

=======
>>>>>>> 4f49083b1cbac423c45740a855ad0bc21491e879
// #endregion
}
