package br.com.serratec.ecommerce.newDTO.formaDePagamento;

public class FormaDePagamentoResponseDTO extends FormaDePagamentoBaseDTO {
    
}
