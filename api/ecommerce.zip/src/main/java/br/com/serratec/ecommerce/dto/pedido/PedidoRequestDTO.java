package br.com.serratec.ecommerce.dto.pedido;

public class PedidoRequestDTO extends PedidoBaseDTO {
    
}
