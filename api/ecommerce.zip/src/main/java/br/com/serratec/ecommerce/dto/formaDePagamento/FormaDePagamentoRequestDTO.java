package br.com.serratec.ecommerce.dto.formaDePagamento;

public class FormaDePagamentoRequestDTO extends FormaDePagamentoBaseDTO {

}
