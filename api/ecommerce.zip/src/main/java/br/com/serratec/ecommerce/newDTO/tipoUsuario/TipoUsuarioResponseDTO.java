package br.com.serratec.ecommerce.newDTO.tipoUsuario;

public class TipoUsuarioResponseDTO extends TipoUsuarioBaseDTO {
    
}
