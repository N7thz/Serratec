package br.com.serratec.ecommerce.dto.pedidoItem;

public class PedidoItemRequestDTO extends PedidoItemBaseDTO {
    
}
