package br.com.serratec.ecommerce.newDTO.formaDePagamento;

public class FormaDePagamentoRequstDTO extends FormaDePagamentoBaseDTO {
    
}
