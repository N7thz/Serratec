package br.com.serratec.ecommerce.newDTO.pedidoItem;

public class PedidoItemRequestDTO extends PedidoItemBaseDTO {
    
}
