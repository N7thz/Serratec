package br.com.serratec.ecommerce.newDTO.pedido;

public class PedidoRequestDTO extends PedidoBaseDTO {
    
}
