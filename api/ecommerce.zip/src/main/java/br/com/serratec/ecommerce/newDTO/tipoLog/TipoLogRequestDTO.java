package br.com.serratec.ecommerce.newDTO.tipoLog;

public class TipoLogRequestDTO extends TipoLogBaseDTO {
    
}
