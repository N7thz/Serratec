package br.com.serratec.ecommerce.dto.usuario;

public class UsuarioResponseDTO extends UsuarioBaseDTO {
    
}
