package br.com.serratec.ecommerce.newDTO.categoria;

public class CategoriaResponseDTO extends CategoriaBaseDTO {
    
}
