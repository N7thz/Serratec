package br.com.serratec.ecommerce.newDTO.log;

public class LogResponseDTO extends LogBaseDTO {
    
}
