package br.com.serratec.ecommerce.newDTO.tipoUsuario;

public class TipoUsuarioRequestDTO extends TipoUsuarioBaseDTO {
    
}
