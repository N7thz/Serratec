package br.com.serratec.ecommerce.newDTO.log;

public class LogRequestDTO extends LogBaseDTO {
    
}
