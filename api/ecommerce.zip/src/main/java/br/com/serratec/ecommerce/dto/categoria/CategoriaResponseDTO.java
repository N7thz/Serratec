package br.com.serratec.ecommerce.dto.categoria;

public class CategoriaResponseDTO extends CategoriaBaseDTO {

    
}


