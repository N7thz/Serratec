package br.com.serratec.ecommerce.newDTO.produto;

public class ProdutoResponseDTO extends ProdutoBaseDTO {
    
}
