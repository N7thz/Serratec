package br.com.serratec.ecommerce.dto.categoria;

public class CategoriaRequestDTO extends CategoriaBaseDTO {}
