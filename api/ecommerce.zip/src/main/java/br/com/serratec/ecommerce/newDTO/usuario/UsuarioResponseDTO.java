package br.com.serratec.ecommerce.newDTO.usuario;

public class UsuarioResponseDTO extends UsuarioBaseDTO {
    
}
