package br.com.serratec.ecommerce.newDTO.categoria;

public class CategoriaRequestDTO extends CategoriaBaseDTO {
    
}
