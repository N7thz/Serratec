package br.com.serratec.ecommerce.dto.produto;

public class ProdutoRequestDTO extends ProdutoBaseDTO {
    
}
