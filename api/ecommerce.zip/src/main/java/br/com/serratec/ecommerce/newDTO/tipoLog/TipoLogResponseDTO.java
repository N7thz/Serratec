package br.com.serratec.ecommerce.newDTO.tipoLog;

public class TipoLogResponseDTO extends TipoLogBaseDTO {
    
}
