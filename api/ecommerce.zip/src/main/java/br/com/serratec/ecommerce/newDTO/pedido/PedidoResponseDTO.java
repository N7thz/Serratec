package br.com.serratec.ecommerce.newDTO.pedido;

public class PedidoResponseDTO extends PedidoBaseDTO {
    
}
