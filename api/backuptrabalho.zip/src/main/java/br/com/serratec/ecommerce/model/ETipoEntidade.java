package br.com.serratec.ecommerce.model;

public enum ETipoEntidade {
    
    PRODUTO,
    PEDIDO,
    USUARIO,
    CATEGORIA
}
