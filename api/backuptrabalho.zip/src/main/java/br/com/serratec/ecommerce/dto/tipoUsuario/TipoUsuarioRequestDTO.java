package br.com.serratec.ecommerce.dto.tipoUsuario;

public class TipoUsuarioRequestDTO {
    
    private String tipoUsu;

    public String getTipoUsu() {
        return tipoUsu;
    }

    public void setTipoUsu(String tipoUsu) {
        this.tipoUsu = tipoUsu;
    }    
}
