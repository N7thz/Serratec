package com.trabalhoapigrupo05.trabalhoapigrupo05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabalhoapigrupo05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
