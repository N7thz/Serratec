![serratec](https://github.com/joe-higashii/space-invaders-app/assets/129689531/00af72d8-daba-48fb-85b5-785ab362a4fd)

# TRABALHO API REST - GRUPO 05

## DESENVOLVIMENTO SOFTWARE FULLSTACK - TURMA 10

### Integrantes:

### GRUPO 05

### VICTOR ANDERSON GONÇALVES WERNEK

### ELAINE DUTRA SILVA

### BRAYAN GAZALÉ SIMÕES COSTA LIMA

### EDUARDO PACHECO CARVALHO

### JOEDSON MENDES DE AMORIM

### NATHAN FELIPE DA SILVA FERREIRA

### TAYNARA AGUIAR REBELLO

## Objetivo:

### Pesquisar, estudar, aprender, aplicar e ensinar ao professor e aos colegas os seguintes temas:

### 1° Swagger (Documentação para API) - 10 pontos

### 2° Importar imagem ou anexos para dentro da API - 20 pontos

### 2.1 Se for imagem, poderá enviar de até 2 formas diferentes.

### 2.1.1 A primeira seria em base64 no body

### 2.1.2 A segunda seria em File, a api deve receber e armazenar no disco fisico do servidor, o caminho onde ela foi salva deve ser salvo em algum lugar.
